import { VideoMakerOptions, ProcessedImage, ProcessedAudio, ProgressCallback } from '../types';
export interface CommandBuilderOptions {
    images: ProcessedImage[];
    audio?: ProcessedAudio;
    options: VideoMakerOptions;
    outputPath: string;
    progressCallback: ProgressCallback;
}
export declare function createFFmpegCommand(options: CommandBuilderOptions): string;
export declare function executeFFmpeg(command: string): Promise<void>;
//# sourceMappingURL=commands.d.ts.map