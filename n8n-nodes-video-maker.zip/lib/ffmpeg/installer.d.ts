export interface FFmpegInstallation {
    path: string;
    version: string;
    isSystemFFmpeg: boolean;
}
export interface InstallationResult {
    success: boolean;
    ffmpeg?: FFmpegInstallation;
    error?: string;
}
declare class FFmpegInstaller {
    private static instance;
    private cachedInstallation;
    private constructor();
    static getInstance(): FFmpegInstaller;
    checkInstallation(): Promise<InstallationResult>;
    private findSystemFFmpeg;
    private findStaticFFmpeg;
    install(): Promise<InstallationResult>;
    private installMacOS;
    private installLinux;
    private installWindows;
    getFFmpegPath(): string | null;
    clearCache(): void;
}
export declare const ffmpegInstaller: FFmpegInstaller;
export { FFmpegInstaller };
//# sourceMappingURL=installer.d.ts.map