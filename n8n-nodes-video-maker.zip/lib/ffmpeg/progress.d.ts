import { FFmpegProgress, LogCallback } from '../types';
export interface ProgressReporterOptions {
    logLevel: 'none' | 'basic' | 'detailed';
    logCallback?: LogCallback;
    estimatedTotalDuration?: number;
}
export declare class ProgressReporter {
    private startTime;
    private lastProgress;
    private progressHistory;
    private readonly logCallback;
    private readonly logLevel;
    constructor(options: ProgressReporterOptions);
    private defaultLogCallback;
    reportProgress(progress: FFmpegProgress): void;
    private formatBasicProgress;
    private formatDetailedProgress;
    private createProgressBar;
    private formatTime;
    private calculateETA;
    reportStart(operation: string): void;
    reportSuccess(operation: string, outputPath: string): void;
    reportError(operation: string, error: string): void;
    reportWarning(message: string): void;
    reportInfo(message: string): void;
    private finalize;
    private calculateAverageSpeed;
    getProgressHistory(): {
        time: number;
        percent: number;
    }[];
    getElapsedTime(): number;
}
export declare function createProgressReporter(options: ProgressReporterOptions): ProgressReporter;
//# sourceMappingURL=progress.d.ts.map