import { VideoMakerOptions } from '../types';
export interface ValidationResult {
    valid: boolean;
    errors: string[];
}
export interface FieldValidation {
    field: string;
    value: unknown;
    valid: boolean;
    message?: string;
}
export declare function validateOptions(options: Partial<VideoMakerOptions>): ValidationResult;
export declare function validateImageUrl(url: string): ValidationResult;
export declare function validateAudioUrl(url: string): ValidationResult;
export declare function validateBinaryData(binaryData: {
    mimeType?: string;
    data?: Buffer;
}, allowedMimeTypes: string[]): ValidationResult;
export declare function validateImageBinary(binaryData: {
    mimeType?: string;
    data?: Buffer;
}): ValidationResult;
export declare function validateAudioBinary(binaryData: {
    mimeType?: string;
    data?: Buffer;
}): ValidationResult;
export declare function validateResolution(width: number, height: number): ValidationResult;
export declare function validateFilePath(filePath: string): ValidationResult;
export declare function sanitizeText(text: string): string;
export declare function parseJsonSafe<T>(json: string, fallback: T): T;
//# sourceMappingURL=validation.d.ts.map