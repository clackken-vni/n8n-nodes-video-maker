export interface TempFile {
    path: string;
    removeCallback: () => void;
}
export interface TempDir {
    path: string;
    removeCallback: () => void;
}
declare class TempManager {
    private static instance;
    private tempDirs;
    private tempFiles;
    private constructor();
    static getInstance(): TempManager;
    createTempDir(prefix?: string): TempDir;
    createTempFile(prefix?: string, suffix?: string): TempFile;
    private cleanupDir;
    cleanup(files: string[]): void;
    cleanupTempDir(tempDir: TempDir): void;
    getFileExtension(mimeType?: string): string;
}
export declare const tempManager: TempManager;
export {};
//# sourceMappingURL=tempManager.d.ts.map