export interface DownloadResult {
    success: boolean;
    filePath?: string;
    error?: string;
    contentType?: string;
    fileSize?: number;
}
export declare function downloadFile(url: string, options?: {
    timeout?: number;
    allowedTypes?: string[];
    allowedExtensions?: string[];
    tempDir?: string;
}): Promise<DownloadResult>;
export declare function downloadImage(url: string, tempDir?: string): Promise<DownloadResult>;
export declare function downloadAudio(url: string, tempDir?: string): Promise<DownloadResult>;
export declare function isValidUrl(url: string): boolean;
export declare function extractUrlsFromText(text: string): string[];
export declare function parseImageUrls(input: string): string[];
//# sourceMappingURL=download.d.ts.map