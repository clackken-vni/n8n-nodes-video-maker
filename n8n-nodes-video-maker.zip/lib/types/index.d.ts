import { IExecuteFunctions, INodeExecutionData, IBinaryData } from 'n8n-workflow';
export interface VideoMakerOptions {
    imagesSource: 'binary' | 'url';
    imagesBinaryProperty: string;
    imageUrls: string[];
    audioSource: 'binary' | 'url';
    audioBinaryProperty: string;
    audioUrl: string;
    outputFormat: 'mp4-h264' | 'mp4-h265' | 'webm';
    resolution: ResolutionPreset | 'custom';
    customWidth?: number;
    customHeight?: number;
    quality: QualityPreset;
    fps: number;
    durationMode: 'match-audio' | 'per-image-total' | 'custom';
    customDuration?: number;
    defaultImageDuration: number;
    defaultTransition: TransitionType;
    transitionDuration: number;
    kenBurnsEnabled: boolean;
    kenBurnsZoom: number;
    kenBurnsDirection: KenBurnsDirection;
    watermarkEnabled: boolean;
    watermarkSource: 'binary' | 'url';
    watermarkBinaryProperty: string;
    watermarkUrl: string;
    watermarkPosition: WatermarkPosition;
    watermarkX?: number;
    watermarkY?: number;
    watermarkOpacity: number;
    watermarkScale: number;
    watermarkMargin: number;
    textOverlayEnabled: boolean;
    textContent: string;
    textPerImage?: TextPerImage[];
    fontName: string;
    fontSize: number;
    fontColor: string;
    fontPath?: string;
    textPosition: TextPosition;
    textX?: number;
    textY?: number;
    textAnimation: TextAnimation;
    animationDuration: number;
    imageOverrides?: ImageOverride[];
    retryCount: number;
    retryDelay: number;
    logLevel: 'none' | 'basic' | 'detailed';
    cleanupTempFiles: boolean;
}
export type ResolutionPreset = '1080p' | '720p' | '480p' | 'vertical-9-16' | 'square-1-1';
export interface Resolution {
    width: number;
    height: number;
}
export declare const RESOLUTION_PRESETS: Record<ResolutionPreset, Resolution>;
export type QualityPreset = 'low' | 'medium' | 'high' | 'ultra';
export declare const QUALITY_PRESETS: Record<QualityPreset, {
    videoBitrate: string;
    audioBitrate: string;
    crf: number;
}>;
export type TransitionType = 'none' | 'fade' | 'slide-left' | 'slide-right' | 'slide-up' | 'slide-down' | 'dissolve' | 'zoom-in' | 'zoom-out' | 'wipe-left' | 'wipe-right' | 'wipe-up' | 'wipe-down' | 'rotate-clockwise' | 'rotate-counterclockwise';
export type KenBurnsDirection = 'zoom-in' | 'zoom-out' | 'pan-left' | 'pan-right' | 'pan-up' | 'pan-down';
export type WatermarkPosition = 'top-left' | 'top-center' | 'top-right' | 'center-left' | 'center' | 'center-right' | 'bottom-left' | 'bottom-center' | 'bottom-right' | 'custom';
export type TextPosition = 'top-left' | 'top-center' | 'top-right' | 'center-left' | 'center' | 'center-right' | 'bottom-left' | 'bottom-center' | 'bottom-right' | 'custom';
export type TextAnimation = 'none' | 'fade-in' | 'fade-out' | 'slide-in' | 'typewriter';
export interface TextPerImage {
    index: number;
    text: string;
}
export interface ImageOverride {
    index: number;
    duration?: number;
    transition?: TransitionType;
    transitionDuration?: number;
    kenBurnsEnabled?: boolean;
    kenBurnsZoom?: number;
    kenBurnsDirection?: KenBurnsDirection;
    text?: string;
}
export interface ProcessedImage {
    path: string;
    width: number;
    height: number;
    duration: number;
    transition?: TransitionType;
    transitionDuration?: number;
    kenBurnsEnabled?: boolean;
    kenBurnsZoom?: number;
    kenBurnsDirection?: KenBurnsDirection;
    text?: string;
    order: number;
}
export interface ProcessedAudio {
    path: string;
    duration: number;
}
export interface FFmpegProgress {
    percent: number;
    currentTime: string;
    totalTime: string;
    fps: number;
    bitrate: string;
    speed: string;
}
export interface FFmpegResult {
    success: boolean;
    outputPath?: string;
    error?: string;
    progress?: FFmpegProgress;
}
export type ProgressCallback = (progress: FFmpegProgress) => void;
export type LogCallback = (level: string, message: string) => void;
export interface NodeExecutionContext {
    executeFunctions: IExecuteFunctions;
    itemIndex: number;
    nodeHelpers: {
        prepareOutputData: (outputData: INodeExecutionData[]) => Promise<INodeExecutionData[]>;
        getBinaryData: (propertyName: string) => Promise<IBinaryData | undefined>;
        downloadImage: (url: string) => Promise<string>;
        downloadAudio: (url: string) => Promise<string>;
        cleanupTempFiles: (paths: string[]) => void;
    };
}
//# sourceMappingURL=index.d.ts.map