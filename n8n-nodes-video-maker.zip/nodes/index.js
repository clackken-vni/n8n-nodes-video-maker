"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoMaker = void 0;
const VideoMaker_node_1 = require("./VideoMaker/VideoMaker.node");
Object.defineProperty(exports, "VideoMaker", { enumerable: true, get: function () { return VideoMaker_node_1.VideoMaker; } });
exports.default = {
    VideoMaker: VideoMaker_node_1.VideoMaker,
};
//# sourceMappingURL=index.js.map