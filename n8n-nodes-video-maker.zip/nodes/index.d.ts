import { VideoMaker } from './VideoMaker/VideoMaker.node';
export { VideoMaker };
declare const _default: {
    VideoMaker: typeof VideoMaker;
};
export default _default;
//# sourceMappingURL=index.d.ts.map