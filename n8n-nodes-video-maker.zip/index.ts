import { VideoMaker } from './nodes/VideoMaker/VideoMaker.node';

export { VideoMaker };

module.exports = {
  VideoMaker,
};

module.exports.default = module.exports;
