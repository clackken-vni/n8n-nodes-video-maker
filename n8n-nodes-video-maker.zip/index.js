module.exports = require('./dist/nodes/VideoMaker/VideoMaker.node');
